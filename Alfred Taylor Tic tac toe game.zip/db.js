const mysql = require("mysql2");

const db = mysql.createConnection({

    host: "localhost",
    user: "gameuser",
    password: "gamepassword",
    database: "tictactoe"

});

db.connect((err) => {

    if (err) {

        console.log("MySQL connection failed");
        console.log(err);

        return;

    }

    console.log("MySQL connected");

});

module.exports = db;
