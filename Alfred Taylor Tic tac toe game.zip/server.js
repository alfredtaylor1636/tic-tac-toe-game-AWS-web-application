const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const db = require("./db");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let connectedPlayers = [];
let games = [];

app.use(express.static("public"));


// Get player list
function getPlayerList(callback) {

    db.query(
        "SELECT screenName FROM users",
        (err, users) => {

            if (err) {
                console.log(err);
                return;
            }

            db.query(
                "SELECT * FROM players",
                (err, playerRows) => {

                    if (err) {
                        console.log(err);
                        return;
                    }

                    let playerList = [];

                    users.forEach(user => {

                        let status = "Idle";
                        let side = "";

                        playerRows.forEach(player => {

                            if (
                                player.x_player === user.screenName &&
                                player.o_player === null
                            ) {

                                status = "Waiting";
                                side = "X";

                            }

                            else if (
                                player.o_player === user.screenName &&
                                player.x_player === null
                            ) {

                                status = "Waiting";
                                side = "O";

                            }

                            else if (
                                player.x_player === user.screenName &&
                                player.o_player !== null
                            ) {

                                status = "Playing";
                                side = "X";

                            }

                            else if (
                                player.o_player === user.screenName &&
                                player.x_player !== null
                            ) {

                                status = "Playing";
                                side = "O";

                            }

                        });

                        playerList.push({
                            screenName: user.screenName,
                            status: status,
                            side: side
                        });

                    });

                    callback(playerList);

                }
            );

        }
    );

}


// Update all clients
function updateAllPlayers() {

    getPlayerList(
        playerList => {

            io.emit(
                "UPDATED-USER-LIST-AND-STATUS",
                playerList
            );

        }
    );

}


// Find connected player
function findPlayer(screenName) {

    return connectedPlayers.find(
        player =>
            player.screenName === screenName
    );

}


// Find game
function findGame(screenName) {

    return games.find(
        game =>
            !game.finished &&
            (
                game.x === screenName ||
                game.o === screenName
            )
    );

}


// Check winner
function getWinner(board) {

    const lines = [

        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],

        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],

        [0, 4, 8],
        [2, 4, 6]

    ];


    for (let line of lines) {

        const a = board[line[0]];
        const b = board[line[1]];
        const c = board[line[2]];


        if (
            a !== "" &&
            a === b &&
            b === c
        ) {

            return a;

        }

    }


    return null;

}


// Check if at least one winning line
// is still possible for this side
function hasPossibleWin(board, side) {

    const lines = [

        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],

        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],

        [0, 4, 8],
        [2, 4, 6]

    ];


    for (let line of lines) {

        let possible = true;


        for (let index of line) {

            // If the square contains the opponent,
            // this line can no longer be won by us.
            if (
                board[index] !== "" &&
                board[index] !== side
            ) {

                possible = false;

                break;

            }

        }


        if (possible) {

            return true;

        }

    }


    return false;

}


// Early draw detection
function isDraw(board) {

    // A winner means it is not a draw.
    if (
        getWinner(board) !== null
    ) {

        return false;

    }


    // If X has no possible winning line
    // and O has no possible winning line,
    // the game is an immediate draw.
    const xCanStillWin =
        hasPossibleWin(
            board,
            "X"
        );


    const oCanStillWin =
        hasPossibleWin(
            board,
            "O"
        );


    if (
        !xCanStillWin &&
        !oCanStillWin
    ) {

        return true;

    }


    return false;

}


// Remove game
function removeGame(game) {

    games =
        games.filter(
            currentGame =>
                currentGame !== game
        );

}


// Finish game
function finishGame(game, result) {

    // Prevent the same game from ending twice.
    if (game.finished) {

        return;

    }


    game.finished = true;


    console.log(
        "FINISHING GAME:",
        game.x,
        "vs",
        game.o,
        "RESULT:",
        result
    );


    // Send result to X immediately
    // instead of waiting for MySQL.
    const xPlayer =
        findPlayer(
            game.x
        );


    if (xPlayer) {

        io.to(
            xPlayer.socketID
        ).emit(
            "END-GAME",
            result
        );

    }


    // Send result to O immediately.
    const oPlayer =
        findPlayer(
            game.o
        );


    if (oPlayer) {

        io.to(
            oPlayer.socketID
        ).emit(
            "END-GAME",
            result
        );

    }


    // Remove the game from memory.
    removeGame(game);


    // Remove players from the players table.
    db.query(
        "DELETE FROM players " +
        "WHERE x_player=? AND o_player=?",
        [
            game.x,
            game.o
        ],
        err => {

            if (err) {

                console.log(err);

            }


            // Update everyone after
            // the database is changed.
            updateAllPlayers();

        }
    );

}


io.on(
    "connection",
    socket => {

        console.log(
            "Connected:",
            socket.id
        );


        // LOGIN
        socket.on(
            "LOGIN",
            screenName => {

                screenName =
                    screenName.trim();


                if (
                    screenName === ""
                ) {

                    socket.emit(
                        "screenname-unavailable"
                    );

                    return;

                }


                db.query(
                    "SELECT * FROM users WHERE screenName=?",
                    [screenName],
                    (err, results) => {

                        if (err) {

                            console.log(err);

                            return;

                        }


                        if (
                            results.length > 0
                        ) {

                            socket.emit(
                                "screenname-unavailable"
                            );

                            return;

                        }


                        db.query(
                            "INSERT INTO users(screenName) VALUES(?)",
                            [screenName],
                            err => {

                                if (err) {

                                    console.log(err);

                                    return;

                                }


                                socket.screenName =
                                    screenName;


                                connectedPlayers.push({

                                    screenName:
                                        screenName,

                                    socketID:
                                        socket.id

                                });


                                getPlayerList(
                                    playerList => {

                                        socket.emit(
                                            "LOGIN-OK",
                                            playerList
                                        );

                                    }
                                );


                                updateAllPlayers();


                                console.log(
                                    screenName +
                                    " logged in"
                                );

                            }
                        );

                    }
                );

            }
        );


        // NEW GAME
        socket.on(
            "NEW-GAME",
            choice => {

                const screenName =
                    socket.screenName;


                if (
                    !screenName
                ) {

                    return;

                }


                if (
                    choice !== "X" &&
                    choice !== "O"
                ) {

                    return;

                }


                if (
                    findGame(screenName)
                ) {

                    return;

                }


                db.query(
                    "SELECT * FROM players " +
                    "WHERE x_player=? OR o_player=?",
                    [
                        screenName,
                        screenName
                    ],
                    (err, results) => {

                        if (err) {

                            console.log(err);

                            return;

                        }


                        if (
                            results.length > 0
                        ) {

                            return;

                        }


                        let sql;


                        if (
                            choice === "X"
                        ) {

                            sql =
                                "INSERT INTO players(x_player,o_player) " +
                                "VALUES(?,NULL)";

                        }

                        else {

                            sql =
                                "INSERT INTO players(x_player,o_player) " +
                                "VALUES(NULL,?)";

                        }


                        db.query(
                            sql,
                            [screenName],
                            err => {

                                if (err) {

                                    console.log(err);

                                    return;

                                }


                                console.log(
                                    screenName +
                                    " is waiting as " +
                                    choice
                                );


                                updateAllPlayers();

                            }
                        );

                    }
                );

            }
        );


        // JOIN GAME
        socket.on(
            "JOIN",
            data => {

                const me =
                    socket.screenName;

                const opponent =
                    data.opponent;


                if (
                    !me ||
                    !opponent
                ) {

                    return;

                }


                // Cannot join yourself
                if (
                    me === opponent
                ) {

                    return;

                }


                // Cannot join if already playing
                if (
                    findGame(me) ||
                    findGame(opponent)
                ) {

                    return;

                }


                // Opponent must be waiting as X
                db.query(
                    "SELECT * FROM players " +
                    "WHERE x_player=? " +
                    "AND o_player IS NULL",
                    [opponent],
                    (err, results) => {

                        if (err) {

                            console.log(err);

                            return;

                        }


                        if (
                            results.length === 0
                        ) {

                            return;

                        }


                        // Delete waiting rows
                        db.query(
                            "DELETE FROM players " +
                            "WHERE x_player=? OR o_player=?",
                            [
                                me,
                                me
                            ],
                            err => {

                                if (err) {

                                    console.log(err);

                                    return;

                                }


                                // Create game
                                db.query(
                                    "INSERT INTO players(x_player,o_player) " +
                                    "VALUES(?,?)",
                                    [
                                        opponent,
                                        me
                                    ],
                                    err => {

                                        if (err) {

                                            console.log(err);

                                            return;

                                        }


                                        const game = {

                                            x:
                                                opponent,

                                            o:
                                                me,

                                            turn:
                                                "X",

                                            finished:
                                                false,

                                            board: [

                                                "",
                                                "",
                                                "",

                                                "",
                                                "",
                                                "",

                                                "",
                                                "",
                                                ""

                                            ]

                                        };


                                        games.push(
                                            game
                                        );


                                        console.log(
                                            "Game created:",
                                            game.x,
                                            "vs",
                                            game.o
                                        );


                                        updateAllPlayers();


                                        // Tell X
                                        const xPlayer =
                                            findPlayer(
                                                game.x
                                            );


                                        if (
                                            xPlayer
                                        ) {

                                            io.to(
                                                xPlayer.socketID
                                            ).emit(
                                                "PLAY",
                                                {
                                                    x:
                                                        game.x,

                                                    o:
                                                        game.o
                                                }
                                            );

                                        }


                                        // Tell O
                                        const oPlayer =
                                            findPlayer(
                                                game.o
                                            );


                                        if (
                                            oPlayer
                                        ) {

                                            io.to(
                                                oPlayer.socketID
                                            ).emit(
                                                "PLAY",
                                                {
                                                    x:
                                                        game.x,

                                                    o:
                                                        game.o
                                                }
                                            );

                                        }

                                    }
                                );

                            }
                        );

                    }
                );

            }
        );


        // MOVE
        socket.on(
            "MOVE",
            data => {

                const screenName =
                    socket.screenName;


                const game =
                    findGame(
                        screenName
                    );


                if (
                    !game ||
                    game.finished
                ) {

                    return;

                }


                let side;


                if (
                    game.x === screenName
                ) {

                    side = "X";

                }

                else if (
                    game.o === screenName
                ) {

                    side = "O";

                }

                else {

                    return;

                }


                // Verify turn
                if (
                    game.turn !== side
                ) {

                    console.log(
                        "Wrong turn:",
                        screenName
                    );

                    return;

                }


                const cell =
                    parseInt(
                        data.cell
                    );


                if (
                    cell < 1 ||
                    cell > 9
                ) {

                    return;

                }


                const index =
                    cell - 1;


                // Cell must be empty
                if (
                    game.board[index] !== ""
                ) {

                    return;

                }


                // Put move on server board
                game.board[index] =
                    side;


                console.log(
                    screenName +
                    " moved " +
                    side +
                    " at cell " +
                    cell
                );


                // FIRST check for a winner
                const winner =
                    getWinner(
                        game.board
                    );


                if (
                    winner
                ) {

                    console.log(
                        "Winner:",
                        winner
                    );


                    finishGame(
                        game,
                        winner
                    );


                    return;

                }


                // THEN check for early draw
                const draw =
                    isDraw(
                        game.board
                    );


                if (
                    draw
                ) {

                    console.log(
                        "EARLY DRAW DETECTED"
                    );


                    finishGame(
                        game,
                        "D"
                    );


                    return;

                }


                // Change turn
                if (
                    game.turn === "X"
                ) {

                    game.turn = "O";

                }

                else {

                    game.turn = "X";

                }


                console.log(
                    "Next turn:",
                    game.turn
                );


                // Find opponent
                let opponentName;


                if (
                    side === "X"
                ) {

                    opponentName =
                        game.o;

                }

                else {

                    opponentName =
                        game.x;

                }


                const opponent =
                    findPlayer(
                        opponentName
                    );


                // Send move to opponent
                if (
                    opponent
                ) {

                    io.to(
                        opponent.socketID
                    ).emit(
                        "MOVE",
                        {
                            cell:
                                cell,

                            side:
                                side,

                            nextTurn:
                                game.turn
                        }
                    );

                }

            }
        );


        // END GAME
        socket.on(
            "END-GAME",
            data => {

                const screenName =
                    socket.screenName;


                const game =
                    findGame(
                        screenName
                    );


                if (
                    !game
                ) {

                    return;

                }


                // Server determines the actual result.
                const winner =
                    getWinner(
                        game.board
                    );


                if (
                    winner
                ) {

                    finishGame(
                        game,
                        winner
                    );

                    return;

                }


                if (
                    isDraw(
                        game.board
                    )
                ) {

                    finishGame(
                        game,
                        "D"
                    );

                    return;

                }


                // Don't allow a client to
                // falsely end an unfinished game.
                console.log(
                    "END-GAME rejected: game is not finished"
                );

            }
        );


        // DISCONNECT
        socket.on(
            "disconnect",
            () => {

                console.log(
                    "Disconnected:",
                    socket.id
                );


                const screenName =
                    socket.screenName;


                connectedPlayers =
                    connectedPlayers.filter(
                        player =>
                            player.socketID !== socket.id
                    );


                if (
                    !screenName
                ) {

                    return;

                }


                const game =
                    findGame(
                        screenName
                    );


                if (
                    game
                ) {

                    removeGame(
                        game
                    );

                }


                db.query(
                    "DELETE FROM players " +
                    "WHERE x_player=? OR o_player=?",
                    [
                        screenName,
                        screenName
                    ],
                    err => {

                        if (err) {

                            console.log(err);

                        }


                        db.query(
                            "DELETE FROM users " +
                            "WHERE screenName=?",
                            [screenName],
                            err => {

                                if (err) {

                                    console.log(err);

                                }


                                updateAllPlayers();

                            }
                        );

                    }
                );

            }
        );

    }
);


// Start server
server.listen(
    3000,
    "0.0.0.0",
    () => {

        console.log(
            "Server running on port 3000"
        );

    }
);
