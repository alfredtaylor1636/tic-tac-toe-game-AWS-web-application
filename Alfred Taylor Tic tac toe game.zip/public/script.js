
const socket = io();

let mySide = "";
let myOpponent = "";

let currentTurn = "X";

let gameActive = false;
let gameOver = false;

let board = [
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    "",
    ""
];


// LOGIN

const loginBtn =
    document.getElementById("loginBtn");


loginBtn.onclick = function() {

    const screenName =
        document
            .getElementById("screenName")
            .value
            .trim();


    if (screenName === "") {

        alert("Please enter a screen name.");

        return;
    }


    socket.emit(
        "LOGIN",
        screenName
    );
};


// LOGIN FAILED

socket.on(
    "screenname-unavailable",
    function() {

        alert(
            "Screen name unavailable. Please try another."
        );

    }
);


// LOGIN OK

socket.on(
    "LOGIN-OK",
    function(playerList) {

        updateList(playerList);

    }
);


// UPDATED USER LIST

socket.on(
    "UPDATED-USER-LIST-AND-STATUS",
    function(playerList) {

        updateList(playerList);

    }
);


// UPDATE LIST

function updateList(playerList) {

    const playerTable =
        document.getElementById("playerList");

    const idleList =
        document.getElementById("idleList");


    const nameInput =
        document.getElementById("screenName");


    let myName = "";


    if (nameInput) {

        myName =
            nameInput.value.trim();

    }


    playerTable.innerHTML = "";

    idleList.innerHTML = "";


    let playingPlayers = [];

    let waitingPlayers = [];


    playerList.forEach(
        function(player) {

            if (
                player.status === "Idle"
            ) {

                const row =
                    document.createElement("div");

                row.textContent =
                    player.screenName;

                idleList.appendChild(row);

            }

            else if (
                player.status === "Playing"
            ) {

                playingPlayers.push(player);

            }

            else if (
                player.status === "Waiting"
            ) {

                waitingPlayers.push(player);

            }

        }
    );


    // Display players who are playing

    let usedPlayers = [];


    playingPlayers.forEach(
        function(player) {

            if (
                usedPlayers.includes(
                    player.screenName
                )
            ) {

                return;

            }


            const row =
                document.createElement("tr");


            const xCell =
                document.createElement("td");


            const separatorCell =
                document.createElement("td");


            const oCell =
                document.createElement("td");


            separatorCell.textContent =
                "|";

            separatorCell.className =
                "separator";


            if (
                player.side === "X"
            ) {

                xCell.textContent =
                    player.screenName;


                const opponent =
                    playingPlayers.find(
                        function(other) {

                            return (
                                other.side === "O" &&
                                !usedPlayers.includes(
                                    other.screenName
                                )
                            );

                        }
                    );


                if (opponent) {

                    oCell.textContent =
                        opponent.screenName;

                    usedPlayers.push(
                        opponent.screenName
                    );

                }


                usedPlayers.push(
                    player.screenName
                );

            }

            else {

                oCell.textContent =
                    player.screenName;


                const opponent =
                    playingPlayers.find(
                        function(other) {

                            return (
                                other.side === "X" &&
                                !usedPlayers.includes(
                                    other.screenName
                                )
                            );

                        }
                    );


                if (opponent) {

                    xCell.textContent =
                        opponent.screenName;

                    usedPlayers.push(
                        opponent.screenName
                    );

                }


                usedPlayers.push(
                    player.screenName
                );

            }


            row.appendChild(xCell);

            row.appendChild(separatorCell);

            row.appendChild(oCell);


            playerTable.appendChild(row);

        }
    );


    // Display waiting players

    waitingPlayers.forEach(
        function(player) {

            const row =
                document.createElement("tr");


            const xCell =
                document.createElement("td");


            const separatorCell =
                document.createElement("td");


            const oCell =
                document.createElement("td");


            separatorCell.textContent =
                "|";

            separatorCell.className =
                "separator";


            const joinButton =
                document.createElement("button");


            joinButton.textContent =
                "JOIN";


            if (
                player.screenName === myName
            ) {

                joinButton.disabled =
                    true;

            }

            else {

                joinButton.onclick =
                    function() {

                        socket.emit(
                            "JOIN",
                            {
                                opponent:
                                    player.screenName
                            }
                        );

                    };

            }


            if (
                player.side === "X"
            ) {

                xCell.textContent =
                    player.screenName;

                oCell.appendChild(
                    joinButton
                );

            }

            else {

                oCell.textContent =
                    player.screenName;

                xCell.appendChild(
                    joinButton
                );

            }


            row.appendChild(xCell);

            row.appendChild(separatorCell);

            row.appendChild(oCell);


            playerTable.appendChild(row);

        }
    );

}


// NEW GAME

const newGameBtn =
    document.getElementById("newGameBtn");


const choiceArea =
    document.getElementById("choiceArea");


newGameBtn.onclick =
    function() {

        newGameBtn.style.display =
            "none";

        choiceArea.style.display =
            "block";

    };


// CHOOSE X

document.getElementById("chooseX").onclick =
    function() {

        mySide = "X";

        choiceArea.style.display =
            "none";

        socket.emit(
            "NEW-GAME",
            "X"
        );

    };


// CHOOSE O

document.getElementById("chooseO").onclick =
    function() {

        mySide = "O";

        choiceArea.style.display =
            "none";

        socket.emit(
            "NEW-GAME",
            "O"
        );

    };


// PLAY

socket.on(
    "PLAY",
    function(data) {

        gameActive = true;

        gameOver = false;


        board = [
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
        ];


        const myName =
            document
                .getElementById("screenName")
                .value
                .trim();


        if (
            data.x === myName
        ) {

            mySide = "X";

            myOpponent =
                data.o;

        }

        else {

            mySide = "O";

            myOpponent =
                data.x;

        }


        currentTurn = "X";


        document.getElementById(
            "xPlayer"
        ).textContent =
            "X: " + data.x;


        document.getElementById(
            "oPlayer"
        ).textContent =
            "O: " + data.o;


        updateTurnDisplay();

        clearBoard();

    }
);


// ALL NINE CELLS

const cells =
    document.querySelectorAll(".cell");


cells.forEach(
    function(cell) {

        cell.addEventListener(
            "click",
            function() {

                makeMove(cell);

            }
        );

    }
);


// MAKE MOVE

function makeMove(cell) {

    if (
        !gameActive ||
        gameOver
    ) {

        return;

    }


    if (
        currentTurn !== mySide
    ) {

        return;

    }


    const cellNumber =
        parseInt(
            cell.dataset.cell
        );


    const index =
        cellNumber - 1;


    if (
        cellNumber < 1 ||
        cellNumber > 9
    ) {

        return;

    }


    if (
        board[index] !== ""
    ) {

        return;

    }


    board[index] =
        mySide;


    cell.textContent =
        mySide;


    cells.forEach(
        function(cell) {

            cell.disabled = true;

        }
    );


    socket.emit(
        "MOVE",
        {
            cell: cellNumber
        }
    );

}


// RECEIVE OPPONENT MOVE

socket.on(
    "MOVE",
    function(data) {

        const cellNumber =
            parseInt(data.cell);


        const index =
            cellNumber - 1;


        if (
            cellNumber < 1 ||
            cellNumber > 9
        ) {

            return;

        }


        if (
            board[index] !== ""
        ) {

            return;

        }


        board[index] =
            data.side;


        const cell =
            document.querySelector(
                '.cell[data-cell="' +
                cellNumber +
                '"]'
            );


        if (cell) {

            cell.textContent =
                data.side;

        }


        currentTurn =
            data.nextTurn;


        updateTurnDisplay();


        cells.forEach(
            function(cell) {

                const cellIndex =
                    parseInt(
                        cell.dataset.cell
                    ) - 1;


                if (
                    board[cellIndex] === "" &&
                    currentTurn === mySide &&
                    !gameOver
                ) {

                    cell.disabled =
                        false;

                }

                else {

                    cell.disabled =
                        true;

                }

            }
        );

    }
);


// UPDATE TURN

function updateTurnDisplay() {

    document.getElementById(
        "turnInfo"
    ).textContent =
        "Turn: " + currentTurn;

}


// CLEAR BOARD

function clearBoard() {

    board = [
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        ""
    ];


    cells.forEach(
        function(cell) {

            cell.textContent = "";


            cell.disabled =
                currentTurn !== mySide;

        }
    );

}


// END GAME

socket.on(
    "END-GAME",
    function(result) {

        console.log(
            "END-GAME received:",
            result
        );


        gameOver = true;

        gameActive = false;


        let message;


        if (
            result === "D"
        ) {

            message =
                "It's a Draw!";

        }

        else if (
            result === mySide
        ) {

            message =
                "You Win!";

        }

        else {

            message =
                "You Lose!";

        }


        document.getElementById(
            "gameResultText"
        ).textContent =
            message;


        document.getElementById(
            "gameResultOverlay"
        ).style.display =
            "flex";


        cells.forEach(
            function(cell) {

                cell.disabled = true;

            }
        );


        newGameBtn.style.display =
            "inline-block";

    }
);


// CLOSE GAME RESULT

document.getElementById(
    "closeGameResult"
).onclick =
    function() {

        document.getElementById(
            "gameResultOverlay"
        ).style.display =
            "none";

    };


// HOW TO PLAY

const helpBtn =
    document.getElementById("helpBtn");


const helpOverlay =
    document.getElementById("helpOverlay");


const closeHelp =
    document.getElementById("closeHelp");


helpBtn.onclick =
    function() {

        helpOverlay.style.display =
            "flex";

    };


closeHelp.onclick =
    function() {

        helpOverlay.style.display =
            "none";

    };


helpOverlay.onclick =
    function(event) {

        if (
            event.target === helpOverlay
        ) {

            helpOverlay.style.display =
                "none";

        }

    };

