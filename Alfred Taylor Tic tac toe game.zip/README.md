COSC 436 Assignment #4
Tic-Tac-Toe Game

By: Alfred Taylor

Features That Do Not Work:

At the time of submission, I only had one thing that I had trouble with is the early draw detection sometimes it picks up one turn before a draw or two.

Also the board clears after selecting new game.

The following features were tested:

- Screen-name login and validation
- How-To-Play overlay
- Player and idle-player lists
- X/O waiting status
- JOIN functionality
- NEW GAME functionality
- X/O selection
- Turn management
- Tic-Tac-Toe board
- Win detection
- Normal draw detection
- Early draw detection
- Game-ending result display
- Returning players to idle status
- Multiple games running simultaneously
- Player status updates
- Socket.IO communication
- MySQL player/status tracking
